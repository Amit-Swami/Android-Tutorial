package com.amitmps.dell.androidtutorials.Interface;

import android.view.View;

public interface ItemOnClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
