package com.example.dell.androidtutorials;

import android.app.Activity;
import android.os.Bundle;

public class Tab1Grid12List3 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab1_grid12_list3);
    }
}
