package com.example.dell.androidtutorials;

public class Tab1_data {
    private String names;
    private int images;

    public Tab1_data(String names,int images)
    {
        this.names=names;
        this.images=images;
    }

    public String getNames() {
        return names;
    }
    public int getImages(){
        return images;
    }
}
